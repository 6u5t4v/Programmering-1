package Opgave_1;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // 1
        String[] array = {"Pax", "Fido", "Molly", "Pluto", "Juno"};

        //2
        System.out.println(Arrays.toString(array));
        System.out.println("-".repeat(30));

        // 3
        array[2] = "King";
        System.out.println(Arrays.toString(array));
        System.out.println("-".repeat(30));

        // 4
        array[1] = "";
        System.out.println(Arrays.toString(array));
        System.out.println("-".repeat(30));

        // 5
        array[1] = "King";
        array[2] = "Pluto";
        array[3] = "Trine";
        System.out.println(Arrays.toString(array));
        System.out.println("-".repeat(30));

        // 6
        array[0] = "Bella";
        System.out.println(Arrays.toString(array));
        System.out.println("-".repeat(30));

        // 7
        System.out.println(array.length);
        System.out.println("-".repeat(30));

        // 8
        int fiveLetterNames = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i].length() == 5) {
                fiveLetterNames++;
            }
        }
        System.out.println(fiveLetterNames);
        System.out.println("-".repeat(30));

        // 9
        for (int i = array.length - 1; i >= 0; i--) {
            System.out.println(array[i]);
        }
        System.out.println("-".repeat(30));

        // 10
        for (int i = 0; i < array.length; i++) {
            if (i % 2 == 0) {
                System.out.println(i + " " + array[i]);
            }
        }
    }
}